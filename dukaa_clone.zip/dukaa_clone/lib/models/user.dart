class UserStore {
  String uid;
  String phoneNumber;

  UserStore(this.uid, this.phoneNumber);

  UserStore.fromMap(data) {
    uid = data['uid'];
    phoneNumber = data['phoneNumber'];
  }

  UserStore.fromUser(user) {
    this.uid = user['uid'];
    this.phoneNumber = user['phoneNumber'];
  }

  Map<String, dynamic> toMap() {
    
  }

}
